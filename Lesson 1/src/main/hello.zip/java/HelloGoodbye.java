public class HelloGoodbye {

//    String firstName;
//    String secondName;
//
//    public HelloGoodbye(String firstName, String secondName){
//        this.firstName = firstName;
//        this.secondName = secondName;
//    }

    public static void main(String[] args) {
        System.out.println("Hello "+ args[0] + " and " + args[1]);
        System.out.println("Goodbye "+ args[1] + " and " + args[0]);
    }
}
